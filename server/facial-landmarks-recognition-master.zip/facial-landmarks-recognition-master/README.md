## facial landmarks recognition 

![My Face](https://i.imgur.com/7IIOka9.png)

### Dependencies 
`pip install numpy opencv-python dlib imutils`

### Run
`python main.py`